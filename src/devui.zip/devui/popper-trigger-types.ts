import type { InjectionKey, Ref } from 'vue';

export const POPPER_TRIGGER_TOKEN: InjectionKey<Ref> = Symbol('popper-trigger');
