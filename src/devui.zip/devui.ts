import { accordionProps } from "./devui/accordion-types";
import { alertProps } from "./devui/alert-types";
import { autoCompleteProps } from "./devui/auto-complete-types";
import { avatarProps } from "./devui/avatar-types";
import { backTopProps } from "./devui/back-top-types";
import { badgeProps } from "./devui/badge-types";
import { bodyTdProps } from "./devui/body-td-types";
import { breadcrumbItemProps } from "./devui/breadcrumb-item-types";
import { breadcrumbProps } from "./devui/breadcrumb-types";
import { buttonProps } from "./devui/button-types";
import { cardProps } from "./devui/card-types";
import { cascaderProps } from "./devui/cascader-types";
import { checkboxProps } from "./devui/checkbox-types";
import { collapseProps } from "./devui/collapse-types";
import { colorPickerBasicColorProps } from "./devui/color-basic-types";
import { colorPickerAlphaSliderProps } from "./devui/color-picker-alpha-slider-types";
import { colorPickerEditProps } from "./devui/color-picker-edit-types";
import { colorPickerHistoryProps } from "./devui/color-picker-history-types";
import { colorPickerHueSliderProps } from "./devui/color-picker-hue-slider-types";
import { colorPickerPaletteProps } from "./devui/color-picker-palette-types";
import { colorPickerProps } from "./devui/color-picker-types";
import { tableColumnProps } from "./devui/column-types";
import { commentProps } from "./devui/comment-types";
import { countdownProps } from "./devui/countdown-types";
import { datePickerProProps } from "./devui/date-picker-pro-types";
import { datePickerProps } from "./devui/date-picker-types";
import { drawerProps } from "./devui/drawer-types";
import { dropdownMenuProps } from "./devui/dropdown-menu-types";
import { dropdownProps } from "./devui/dropdown-types";
import { editableSelectProps } from "./devui/editable-select-types";
import { filterProps } from "./devui/filter-types";
import { fixedOverlayProps } from "./devui/fixed-overlay-types";
import { flexibleOverlayProps } from "./devui/flexible-overlay-types";
import { formControlProps } from "./devui/form-control-types";
import { formItemProps } from "./devui/form-item-types";
import { formLabelProps } from "./devui/form-label-types";
import { formProps } from "./devui/form-types";
import { fullscreenProps } from "./devui/fullscreen-types";
import { ganttProps } from "./devui/gantt-types";
import { headerThProps } from "./devui/header-th-types";
import { iconProps } from "./devui/icon-types";
import { imagePreviewProps } from "./devui/image-preview-types";
import { inputNumberProps } from "./devui/input-number-types";
import { inputProps } from "./devui/input-types";
import { loadingProps } from "./devui/loading-types";
import { mentionProps } from "./devui/mention-types";
import { menuItemProps } from "./devui/menu-item-types";
import { menuProps } from "./devui/menu-types";
import { messageProps } from "./devui/message-types";
import { modalProps } from "./devui/modal-types";
import { multiAutoCompleteProps } from "./devui/multi-auto-complete-types";
import { navSpriteProps } from "./devui/nav-sprite-types";
import { notificationProps } from "./devui/notification-types";
import { paginationProps } from "./devui/pagination-types";
import { panelProps } from "./devui/panel-types";
import { popoverProps } from "./devui/popover-types";
import { popupLineProps } from "./devui/popup-line-types";
import { progressProps } from "./devui/progress-types";
import { quadrantDiagramProps } from "./devui/quadrant-diagram-types";
import { radioProps } from "./devui/radio-types";
import { rangeDatePickerProProps } from "./devui/range-date-picker-types";
import { rateProps } from "./devui/rate-types";
import { readTipProps } from "./devui/read-tip-types";
import { resultProps } from "./devui/result-types";
import { searchProps } from "./devui/search-types";
import { selectProps } from "./devui/select-types";
import { skeletonItemProps } from "./devui/skeleton-item-types";
import { skeletonProps } from "./devui/skeleton-types";
import { sliderProps } from "./devui/slider-types";
import { sortProps } from "./devui/sort-types";
import { splitterBarProps } from "./devui/splitter-bar-types";
import { splitterPaneProps } from "./devui/splitter-pane-types";
import { splitterProps } from "./devui/splitter-types";
import { statisticProps } from "./devui/statistic-types";
import { stepsGuideProps } from "./devui/steps-guide-types";
import { stepsProps } from "./devui/steps-types";
import { stepProps } from "./devui/step-types";
import { subMenuProps } from "./devui/sub-menu-types";
import { switchProps } from "./devui/switch-types";
import { tableProps } from "./devui/table-types";
import { tabsProps } from "./devui/tabs-types";
import { tabProps } from "./devui/tab-types";
import { tagInputProps } from "./devui/tag-input-types";
import { tagProps } from "./devui/tag-types";
import { textareaProps } from "./devui/textarea-types";
import { timeAxisItemProps } from "./devui/time-axis-item-types";
import { timeAxisProps } from "./devui/time-axis-types";
import { timePickerProps } from "./devui/time-picker-types";
import { timePopupProps } from "./devui/time-popup-types";
import { timeSelectProps } from "./devui/time-select-types";
import { tooltipProps } from "./devui/tooltip-types";
import { transferProps } from "./devui/transfer-types";
import { treeSelectProps } from "./devui/tree-select-types";
import { treeProps } from "./devui/tree-types";
import { uploadProps } from "./devui/upload-types";
import { virtualListProps } from "./devui/virtual-list-types";


let devui = {
    accordionProps,
    alertProps,
    autoCompleteProps,
    avatarProps,
    backTopProps,
    badgeProps,
    bodyTdProps,
    breadcrumbItemProps,
    breadcrumbProps,
    buttonProps,
    cardProps,
    cascaderProps,
    checkboxProps,
    collapseProps,
    colorPickerBasicColorProps,
    colorPickerAlphaSliderProps,
    colorPickerEditProps,
    colorPickerHistoryProps,
    colorPickerHueSliderProps,
    colorPickerPaletteProps,
    colorPickerProps,
    tableColumnProps,
    commentProps,
    countdownProps,
    datePickerProProps,
    datePickerProps,
    drawerProps,
    dropdownMenuProps,
    dropdownProps,
    editableSelectProps,
    filterProps,
    fixedOverlayProps,
    flexibleOverlayProps,
    formControlProps,
    formItemProps,
    formLabelProps,
    formProps,
    fullscreenProps,
    ganttProps,
    headerThProps,
    iconProps,
    imagePreviewProps,
    inputNumberProps,
    inputProps,
    loadingProps,
    mentionProps,
    menuItemProps,
    menuProps,
    messageProps,
    modalProps,
    multiAutoCompleteProps,
    navSpriteProps,
    notificationProps,
    paginationProps,
    panelProps,
    popoverProps,
    popupLineProps,
    progressProps,
    quadrantDiagramProps,
    radioProps,
    rangeDatePickerProProps,
    rateProps,
    readTipProps,
    resultProps,
    searchProps,
    selectProps,
    skeletonItemProps,
    skeletonProps,
    sliderProps,
    sortProps,
    splitterBarProps,
    splitterPaneProps,
    splitterProps,
    statisticProps,
    stepsGuideProps,
    stepsProps,
    stepProps,
    subMenuProps,
    switchProps,
    tableProps,
    tabsProps,
    tabProps,
    tagInputProps,
    tagProps,
    textareaProps,
    timeAxisItemProps,
    timeAxisProps,
    timePickerProps,
    timePopupProps,
    timeSelectProps,
    tooltipProps,
    transferProps,
    treeSelectProps,
    treeProps,
    uploadProps,
    virtualListProps,

}


export default devui;

